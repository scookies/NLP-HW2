package edu.berkeley.nlp.assignments;

import edu.berkeley.nlp.io.PennTreebankReader;
import edu.berkeley.nlp.ling.Tree;
import edu.berkeley.nlp.ling.Trees;
import edu.berkeley.nlp.util.*;

import java.util.*;

import static edu.berkeley.nlp.math.SloppyMath.logAdd;
import static edu.berkeley.nlp.math.SloppyMath.max;

/**
 * @author Dan Klein
 */
public class POSTaggerTester {

  static final String START_WORD = "<S>";
  static final String STOP_WORD = "</S>";
  static final String START_TAG = "<S>";
  static final String STOP_TAG = "</S>";

  /**
   * Tagged sentences are a bundling of a list of words and a list of their
   * tags.
   */
  static class TaggedSentence {
    List<String> words;
    List<String> tags;

    public int size() {
      return words.size();
    }

    public List<String> getWords() {
      return words;
    }

    public List<String> getTags() {
      return tags;
    }

    public String toString() {
      StringBuilder sb = new StringBuilder();
      for (int position = 0; position < words.size(); position++) {
        String word = words.get(position);
        String tag = tags.get(position);
        sb.append(word);
        sb.append("_");
        sb.append(tag);
      }
      return sb.toString();
    }

    public boolean equals(Object o) {
      if (this == o) return true;
      if (!(o instanceof TaggedSentence)) return false;

      final TaggedSentence taggedSentence = (TaggedSentence) o;

      if (tags != null ? !tags.equals(taggedSentence.tags) : taggedSentence.tags != null) return false;
      if (words != null ? !words.equals(taggedSentence.words) : taggedSentence.words != null) return false;

      return true;
    }

    public int hashCode() {
      int result;
      result = (words != null ? words.hashCode() : 0);
      result = 29 * result + (tags != null ? tags.hashCode() : 0);
      return result;
    }

    public TaggedSentence(List<String> words, List<String> tags) {
      this.words = words;
      this.tags = tags;
    }
  }

  /**
   * States are pairs of tags along with a position index, representing the two
   * tags preceding that position.  So, the START state, which can be gotten by
   * State.getStartState() is [START, START, 0].  To build an arbitrary state,
   * for example [DT, NN, 2], use the static factory method
   * State.buildState("DT", "NN", 2).  There isnt' a single final state, since
   * sentences lengths vary, so State.getEndState(i) takes a parameter for the
   * length of the sentence.
   */
  static class State {

    private static transient Interner<State> stateInterner = new Interner<State>(new Interner.CanonicalFactory<State>() {
      public State build(State state) {
        return new State(state);
      }
    });

    private static transient State tempState = new State();

    public static State getStartState() {
      return buildState(START_TAG, START_TAG, 0);
    }

    public static State getStopState(int position) {
      return buildState(STOP_TAG, STOP_TAG, position);
    }

    public static State buildState(String previousPreviousTag, String previousTag, int position) {
      tempState.setState(previousPreviousTag, previousTag, position);
      return stateInterner.intern(tempState);
    }

    public static List<String> toTagList(List<State> states) {
      List<String> tags = new ArrayList<String>();
      if (states.size() > 0) {
        tags.add(states.get(0).getPreviousPreviousTag());
        for (State state : states) {
          tags.add(state.getPreviousTag());
        }
      }
      return tags;
    }

    public int getPosition() {
      return position;
    }

    public String getPreviousTag() {
      return previousTag;
    }

    public String getPreviousPreviousTag() {
      return previousPreviousTag;
    }

    public State getNextState(String tag) {
      return State.buildState(getPreviousTag(), tag, getPosition() + 1);
    }

    public State getPreviousState(String tag) {
      return State.buildState(tag, getPreviousPreviousTag(), getPosition() - 1);
    }

    public boolean equals(Object o) {
      if (this == o) return true;
      if (!(o instanceof State)) return false;

      final State state = (State) o;

      if (position != state.position) return false;
      if (previousPreviousTag != null ? !previousPreviousTag.equals(state.previousPreviousTag) : state.previousPreviousTag != null) return false;
      if (previousTag != null ? !previousTag.equals(state.previousTag) : state.previousTag != null) return false;

      return true;
    }

    public int hashCode() {
      int result;
      result = position;
      result = 29 * result + (previousTag != null ? previousTag.hashCode() : 0);
      result = 29 * result + (previousPreviousTag != null ? previousPreviousTag.hashCode() : 0);
      return result;
    }

    public String toString() {
      return "[" + getPreviousPreviousTag() + ", " + getPreviousTag() + ", " + getPosition() + "]";
    }

    int position;
    String previousTag;
    String previousPreviousTag;

    private void setState(String previousPreviousTag, String previousTag, int position) {
      this.previousPreviousTag = previousPreviousTag;
      this.previousTag = previousTag;
      this.position = position;
    }

    private State() {
    }

    private State(State state) {
      setState(state.getPreviousPreviousTag(), state.getPreviousTag(), state.getPosition());
    }
  }

  /**
   * A Trellis is a graph with a start state an an end state, along with
   * successor and predecessor functions.
   */
  static class Trellis <S> {
    S startState;
    S endState;
    CounterMap<S, S> forwardTransitions;
    CounterMap<S, S> backwardTransitions;

    /**
     * Get the unique start state for this trellis.
     */
    public S getStartState() {
      return startState;
    }

    public void setStartState(S startState) {
      this.startState = startState;
    }

    /**
     * Get the unique end state for this trellis.
     */
    public S getEndState() {
      return endState;
    }

    public void setStopState(S endState) {
      this.endState = endState;
    }

    /**
     * For a given state, returns a counter over what states can be next in the
     * markov process, along with the cost of that transition.  Caution: a state
     * not in the counter is illegal, and should be considered to have cost
     * Double.NEGATIVE_INFINITY, but Counters score items they don't contain as
     * 0.
     */
    public Counter<S> getForwardTransitions(S state) {
      return forwardTransitions.getCounter(state);

    }


    /**
     * For a given state, returns a counter over what states can precede it in
     * the markov process, along with the cost of that transition.
     */
    public Counter<S> getBackwardTransitions(S state) {
      return backwardTransitions.getCounter(state);
    }

    public void setTransitionCount(S start, S end, double count) {
      forwardTransitions.setCount(start, end, count);
      backwardTransitions.setCount(end, start, count);
    }

    public Trellis() {
      forwardTransitions = new CounterMap<S, S>();
      backwardTransitions = new CounterMap<S, S>();
    }
  }

  /**
   * A TrellisDecoder takes a Trellis and returns a path through that trellis in
   * which the first item is trellis.getStartState(), the last is
   * trellis.getEndState(), and each pair of states is conntected in the
   * trellis.
   */
  static interface TrellisDecoder <S> {
    List<S> getBestPath(Trellis<S> trellis);
  }

  static class GreedyDecoder <S> implements TrellisDecoder<S> {
    public List<S> getBestPath(Trellis<S> trellis) {
      List<S> states = new ArrayList<S>();
      S currentState = trellis.getStartState();
      states.add(currentState);
      while (!currentState.equals(trellis.getEndState())) {
        Counter<S> transitions = trellis.getForwardTransitions(currentState);
        S nextState = transitions.argMax();
        states.add(nextState);
        currentState = nextState;
      }
      return states;
    }
  }

  static class Viterbi <S> implements TrellisDecoder<S>
  {
      HashMap<S, List<S>> foundPath = new HashMap<S, List<S>>();   //the best path to reach to a state
      HashMap<S, Double>  foundScore = new HashMap<S, Double>();   //the best score found to a state

      private double viterbiScore(S currentState, Trellis<S> trellis )
      {
        if(currentState == State.getStartState())
            return 1;
        else
        {
            double maxFoundPi = 0.0;
            double currentPi = 0.0;
            //S bestFoundState = currentState; //bug bug: not a good way to initiate
            for(S possiblePrevState: trellis.getBackwardTransitions(currentState).keySet()) //get all the key for prev prev state
            {
                currentPi = trellis.getBackwardTransitions(currentState).getCount(possiblePrevState);
                currentPi = logAdd (currentPi, viterbiScore(possiblePrevState, trellis));
                if(currentPi>maxFoundPi)
                {
                    //bestFoundState = possiblePrevState;
                    maxFoundPi = currentPi;
                }

            }
            return maxFoundPi;
        }
      }

      private double viterbiScoreOld(S proposedState, Trellis<S> trellis, List<S> states )
      {
          if(proposedState == State.getStartState())
              return 1;
          else if(((State)proposedState).position == 0)
              return 0;
          else
          {
              double prevScore = viterbiScoreOld(states.get(((State)proposedState).position-1), trellis, states);
              double proposedStateScore = 0.0;
              boolean fFound = false;
              for(S possiblePrevState: trellis.getBackwardTransitions(proposedState).keySet())
              {
                  for(S nextStateOfPrevState: trellis.getForwardTransitions(possiblePrevState).keySet())
                  {
                      if(nextStateOfPrevState.equals(proposedState))
                      {
                          proposedStateScore =  trellis.getForwardTransitions(possiblePrevState).getCount(nextStateOfPrevState);
                          fFound = true;
                      }
                      if(fFound)
                          break;
                  }
                  if(fFound)
                      break;
              }
              return logAdd(prevScore , proposedStateScore);
          }
      }

     /** public List<S> getBestPath(Trellis<S> trellis)
      {
          List<S> states = new ArrayList<S>();
          S currentState = trellis.getStartState();
          double score = 0.0;
          double bestFoundScore = 0.0;
          S bestFoundState = trellis.getStartState();
          states.add(currentState);
          while (!currentState.equals(trellis.getEndState())) {
              Counter<S> transitions = trellis.getForwardTransitions(currentState);
              double previousScore = viterbiScore(currentState, trellis);
              for(S possibleState: transitions.keySet())
              {
                  score = logAdd(previousScore, trellis.getBackwardTransitions(possibleState).getCount(currentState));

                  if(score > bestFoundScore)
                  {
                      bestFoundScore = score;
                      bestFoundState = possibleState;
                  }
              }
              states.add(bestFoundState);
              currentState = bestFoundState;
          }
          return states;
      }**/

      private double getBestPrevPath(S state, List<S> path, Trellis<S> trellis)
      {
        if(state == State.getStartState())
        {
            path.add(state);
            return 1;
        }
          double score = 0.0;
          double bestFoundScore = 0.0;
          S savedState = state;
          List<S> bestFoundPath = new ArrayList<S>();
          for(S prevState: trellis.getBackwardTransitions(state).keySet())
          {
              if(foundScore.containsKey(prevState))
                  score = foundScore.get(prevState).doubleValue();
              else
              {
                  List<S> localPath = new ArrayList<S>();
                  score = getBestPrevPath(prevState, localPath, trellis);    //calculate it if not there.
                  foundScore.put(prevState, score);
                  foundPath.put(prevState, localPath);
              }
              if(score>bestFoundScore)
              {
                  bestFoundScore = score;
                  bestFoundPath = foundPath.get(prevState);
                  savedState = prevState;
              }
          }
          bestFoundPath.add(state);
          path = bestFoundPath; //replace the old path with the new path
          foundPath.put(state, bestFoundPath);   // add found score for base
          score = logAdd(bestFoundScore, trellis.getForwardTransitions(savedState).getCount(state)); //reusing the name just for saving
          foundScore.put(state, score);
          return score;
      }

      public List<S> getBestPath(Trellis<S> trellis)
      {
        List<S> states = new ArrayList<S>();        //this will keep track of the best found path
        S currentState = trellis.getStartState();
        double score = 0.0;
        double bestFoundScore = 0.0;
        List<S> bestFoundPath = new ArrayList<S>();
        S bestFoundState = trellis.getStartState();

        states.add(currentState);
        foundPath.put(currentState, states);   // add found score for base
        foundScore.put(currentState, 1.0);

        while (!currentState.equals(trellis.getEndState())) {
            S savedState = currentState;
            Counter<S> transitions = trellis.getForwardTransitions(currentState);
            S nextState = transitions.argMax();     //current best next state
            for(S prevState: trellis.getBackwardTransitions(nextState).keySet())
            {
                if(foundScore.containsKey(prevState))
                    score = foundScore.get(prevState).doubleValue();
                else
                {
                    List<S> path = new ArrayList<S>();
                    score = getBestPrevPath(prevState, path, trellis);    //calculate it if not there.
                    foundScore.put(prevState, score);
                    foundPath.put(prevState, path);
                }
                if(score>bestFoundScore)
                {
                   bestFoundScore = score;
                   bestFoundPath = foundPath.get(prevState);
                    savedState = prevState;
                }
            }
            bestFoundPath.add(nextState);
            states = bestFoundPath; //replace the old path with the new path
            foundPath.put(nextState, bestFoundPath);   // add found score for base
            foundScore.put(nextState, logAdd(bestFoundScore, trellis.getForwardTransitions(savedState).getCount(nextState)));
            currentState = nextState;
        }
        return states;
      }
  }

  static class POSTagger {

    LocalTrigramScorer localTrigramScorer;
    TrellisDecoder<State> trellisDecoder;

    // chop up the training instances into local contexts and pass them on to the local scorer.
    public void train(List<TaggedSentence> taggedSentences) {
      localTrigramScorer.train(extractLabeledLocalTrigramContexts(taggedSentences));
    }

    // chop up the validation instances into local contexts and pass them on to the local scorer.
    public void validate(List<TaggedSentence> taggedSentences) {
      localTrigramScorer.validate(extractLabeledLocalTrigramContexts(taggedSentences));
    }

    private List<LabeledLocalTrigramContext> extractLabeledLocalTrigramContexts(List<TaggedSentence> taggedSentences) {
      List<LabeledLocalTrigramContext> localTrigramContexts = new ArrayList<LabeledLocalTrigramContext>();
      for (TaggedSentence taggedSentence : taggedSentences) {
        localTrigramContexts.addAll(extractLabeledLocalTrigramContexts(taggedSentence));
      }
      return localTrigramContexts;
    }

    private List<LabeledLocalTrigramContext> extractLabeledLocalTrigramContexts(TaggedSentence taggedSentence) {
      List<LabeledLocalTrigramContext> labeledLocalTrigramContexts = new ArrayList<LabeledLocalTrigramContext>();
      List<String> words = new BoundedList<String>(taggedSentence.getWords(), START_WORD, STOP_WORD);
      List<String> tags = new BoundedList<String>(taggedSentence.getTags(), START_TAG, STOP_TAG);
      for (int position = 0; position <= taggedSentence.size() + 1; position++) {
        labeledLocalTrigramContexts.add(new LabeledLocalTrigramContext(words, position, tags.get(position - 2), tags.get(position - 1), tags.get(position)));
      }
      return labeledLocalTrigramContexts;
    }

    /**
     * Builds a Trellis over a sentence, by starting at the state State, and
     * advancing through all legal extensions of each state already in the
     * trellis.  You should not have to modify this code (or even read it,
     * really).
     */
    private Trellis<State> buildTrellis(List<String> sentence) {
      Trellis<State> trellis = new Trellis<State>();
      trellis.setStartState(State.getStartState());
      State stopState = State.getStopState(sentence.size() + 2);
      trellis.setStopState(stopState);
      Set<State> states = Collections.singleton(State.getStartState());
      for (int position = 0; position <= sentence.size() + 1; position++) {
        Set<State> nextStates = new HashSet<State>();
        for (State state : states) {
          if (state.equals(stopState))
            continue;
          LocalTrigramContext localTrigramContext = new LocalTrigramContext(sentence, position, state.getPreviousPreviousTag(), state.getPreviousTag());
          Counter<String> tagScores = localTrigramScorer.getLogScoreCounter(localTrigramContext);
          for (String tag : tagScores.keySet()) {
            double score = tagScores.getCount(tag);
            State nextState = state.getNextState(tag);
            trellis.setTransitionCount(state, nextState, score);
            nextStates.add(nextState);
          }
        }
//        System.out.println("States: "+nextStates);
        states = nextStates;
      }
      return trellis;
    }

    // to tag a sentence: build its trellis and find a path through that trellis
    public List<String> tag(List<String> sentence) {
      Trellis<State> trellis = buildTrellis(sentence);
      List<State> states = trellisDecoder.getBestPath(trellis);
      List<String> tags = State.toTagList(states);
      tags = stripBoundaryTags(tags);
      return tags;
    }

    /**
     * Scores a tagging for a sentence.  Note that a tag sequence not accepted
     * by the markov process should receive a log score of
     * Double.NEGATIVE_INFINITY.
     */
    public double scoreTagging(TaggedSentence taggedSentence) {
      double logScore = 0.0;
      List<LabeledLocalTrigramContext> labeledLocalTrigramContexts = extractLabeledLocalTrigramContexts(taggedSentence);
      for (LabeledLocalTrigramContext labeledLocalTrigramContext : labeledLocalTrigramContexts) {
        Counter<String> logScoreCounter = localTrigramScorer.getLogScoreCounter(labeledLocalTrigramContext);
        String currentTag = labeledLocalTrigramContext.getCurrentTag();
        if (logScoreCounter.containsKey(currentTag)) {
          logScore += logScoreCounter.getCount(currentTag);
        } else {
          logScore += Double.NEGATIVE_INFINITY;
        }
      }
      return logScore;
    }

    private List<String> stripBoundaryTags(List<String> tags) {
      return tags.subList(2, tags.size() - 2);
    }

    public POSTagger(LocalTrigramScorer localTrigramScorer, TrellisDecoder<State> trellisDecoder) {
      this.localTrigramScorer = localTrigramScorer;
      this.trellisDecoder = trellisDecoder;
    }
  }

  /**
   * A LocalTrigramContext is a position in a sentence, along with the previous
   * two tags -- basically a FeatureVector.
   */
  static class LocalTrigramContext {
    List<String> words;
    int position;
    String previousTag;
    String previousPreviousTag;

    public List<String> getWords() {
      return words;
    }

    public String getCurrentWord() {
      return words.get(position);
    }

    public int getPosition() {
      return position;
    }

    public String getPreviousTag() {
      return previousTag;
    }

    public String getPreviousPreviousTag() {
      return previousPreviousTag;
    }

    public String toString() {
      return "[" + getPreviousPreviousTag() + ", " + getPreviousTag() + ", " + getCurrentWord() + "]";
    }

    public LocalTrigramContext(List<String> words, int position, String previousPreviousTag, String previousTag) {
      this.words = words;
      this.position = position;
      this.previousTag = previousTag;
      this.previousPreviousTag = previousPreviousTag;
    }
  }

  /**
   * A LabeledLocalTrigramContext is a context plus the correct tag for that
   * position -- basically a LabeledFeatureVector
   */
  static class LabeledLocalTrigramContext extends LocalTrigramContext {
    String currentTag;

    public String getCurrentTag() {
      return currentTag;
    }

    public String toString() {
      return "[" + getPreviousPreviousTag() + ", " + getPreviousTag() + ", " + getCurrentWord() + "_" + getCurrentTag() + "]";
    }

    public LabeledLocalTrigramContext(List<String> words, int position, String previousPreviousTag, String previousTag, String currentTag) {
      super(words, position, previousPreviousTag, previousTag);
      this.currentTag = currentTag;
    }
  }

  /**
   * LocalTrigramScorers assign scores to tags occuring in specific
   * LocalTrigramContexts.
   */
  static interface LocalTrigramScorer {
    /**
     * The Counter returned should contain log probabilities, meaning if all
     * values are exponentiated and summed, they should sum to one (if it's a 
	 * single conditional pobability). For efficiency, the Counter can 
	 * contain only the tags which occur in the given context 
	 * with non-zero model probability.
     */
    Counter<String> getLogScoreCounter(LocalTrigramContext localTrigramContext);

    void train(List<LabeledLocalTrigramContext> localTrigramContexts);

    void validate(List<LabeledLocalTrigramContext> localTrigramContexts);
  }

  /**
   * The MostFrequentTagScorer gives each test word the tag it was seen with
   * most often in training (or the tag with the most seen word types if the
   * test word is unseen in training.  This scorer actually does a little more
   * than its name claims -- if constructed with restrictTrigrams = true, it
   * will forbid illegal tag trigrams, otherwise it makes no use of tag history
   * information whatsoever.
   */
  static class MostFrequentTagScorer implements LocalTrigramScorer {

    boolean restrictTrigrams; // if true, assign log score of Double.NEGATIVE_INFINITY to illegal tag trigrams.

    CounterMap<String, String> wordsToTags = new CounterMap<String, String>();
    Counter<String> unknownWordTags = new Counter<String>();
    Set<String> seenTagTrigrams = new HashSet<String>();

    public int getHistorySize() {
      return 2;
    }

    public Counter<String> getLogScoreCounter(LocalTrigramContext localTrigramContext) {
      int position = localTrigramContext.getPosition();
      String word = localTrigramContext.getWords().get(position);
      Counter<String> tagCounter = unknownWordTags;
      if (wordsToTags.keySet().contains(word)) {
        tagCounter = wordsToTags.getCounter(word);
      }
      Set<String> allowedFollowingTags = allowedFollowingTags(tagCounter.keySet(), localTrigramContext.getPreviousPreviousTag(), localTrigramContext.getPreviousTag());
      Counter<String> logScoreCounter = new Counter<String>();
      for (String tag : tagCounter.keySet()) {
        double logScore = Math.log(tagCounter.getCount(tag));
        if (!restrictTrigrams || allowedFollowingTags.isEmpty() || allowedFollowingTags.contains(tag))
          logScoreCounter.setCount(tag, logScore);
      }
      return logScoreCounter;
    }

    private Set<String> allowedFollowingTags(Set<String> tags, String previousPreviousTag, String previousTag) {
      Set<String> allowedTags = new HashSet<String>();
      for (String tag : tags) {
        String trigramString = makeTrigramString(previousPreviousTag, previousTag, tag);
        if (seenTagTrigrams.contains((trigramString))) {
          allowedTags.add(tag);
        }
      }
      return allowedTags;
    }

    private String makeTrigramString(String previousPreviousTag, String previousTag, String currentTag) {
      return previousPreviousTag + " " + previousTag + " " + currentTag;
    }

    public void train(List<LabeledLocalTrigramContext> labeledLocalTrigramContexts) {
      // collect word-tag counts
      for (LabeledLocalTrigramContext labeledLocalTrigramContext : labeledLocalTrigramContexts) {
        String word = labeledLocalTrigramContext.getCurrentWord();
        String tag = labeledLocalTrigramContext.getCurrentTag();
        if (!wordsToTags.keySet().contains(word)) {
          // word is currently unknown, so tally its tag in the unknown tag counter
          unknownWordTags.incrementCount(tag, 1.0);
        }
        wordsToTags.incrementCount(word, tag, 1.0);
        seenTagTrigrams.add(makeTrigramString(labeledLocalTrigramContext.getPreviousPreviousTag(), labeledLocalTrigramContext.getPreviousTag(), labeledLocalTrigramContext.getCurrentTag()));
      }
      wordsToTags = Counters.conditionalNormalize(wordsToTags);
      unknownWordTags = Counters.normalize(unknownWordTags);
    }

    public void validate(List<LabeledLocalTrigramContext> labeledLocalTrigramContexts) {
      // no tuning for this dummy model!
    }

    public MostFrequentTagScorer(boolean restrictTrigrams) {
      this.restrictTrigrams = restrictTrigrams;
    }
  }

    /**
     * This is a better scorer which uses HM instead of just finding the word by one tag lookup
     */
    static class BetterTagScorer implements LocalTrigramScorer{
        boolean restrictTrigrams; // if true, assign log score of Double.NEGATIVE_INFINITY to illegal tag trigrams.

        CounterMap<String, String> wordsToTags = new CounterMap<String, String>();
        CounterMap<String, String> unkWordsToTags = new CounterMap<String, String>();
        CounterMap<String, String> tagsToWords = new CounterMap<String, String>();
        Counter<String> unknownWordTags = new Counter<String>();  //remove this?
        Counter<String> seenWords = new Counter<String>();

        Counter<String> trigramTagStrings = new Counter<String>();
        Counter<String> bigramTagStrings = new Counter<String>();
        Counter<String> unigramTagStrings = new Counter<String>();
        Set<String> trigramTagsCnt = new HashSet<String>();
        Set<String> bigramTagsCnt = new HashSet<String>();

        //lambdas
        double lambda1 = 1.0/3;
        double lambda2 = 1.0/3;
        double lambda3 = 1-(lambda1 + lambda2) ;

        private String getPseudoString(String str)
        {
            if(str.matches("[0-9]{2}"))
                return "twoDigitNum";
            if(str.matches("[0-9]{4}"))
                return "fourDigitNum";
            if(str.matches("[0-9]+-[0-9]+"))
                return "containsDigitAndDash";
            if(str.matches("[0-9A-Z]+-[0-9A-Z]+"))
                return "containsDigitAndAlpha";
            if(str.matches("[0-9]+/[0-9]+(/[0-9]+)?"))
                return "containsDigitAndSlash";
            if(str.matches("[0-9]+(,[0-9]+)+"))
                return "containsDigitAndCommas";
            if(str.matches("[0-9]+(.[0-9]+)+"))
                return "containsDigitAndPeriod";
            if(str.matches("[0-9]*]"))
                return "allDigit";
            if(str.matches("[A-Z]+"))
                return "allCaps";
            if(str.matches("[A-Z]\\."))
                return "capPeriod";
            if(str.matches("[A-Z][a-z]+"))
                return "initCap";
            if(str.matches("[a-z]+"))
                return "lowercase";
            if(str.matches("[^a-zA-Z0-9]+"))
                return "noAlphaDigit";
            else
                return "unknown";
        }

        public Counter<String> getLogScoreCounter(LocalTrigramContext localTrigramContext) {
            int position = localTrigramContext.getPosition();
            String word = localTrigramContext.getWords().get(position);
            Counter<String> tagCounter = unknownWordTags;
            if (!wordsToTags.keySet().contains(word))
            {
                word = getPseudoString(word);
            }
            if(!wordsToTags.keySet().contains(word))
            {
                System.out.println("Pseudo: " + word + " also is not in the list");
            }

                tagCounter = wordsToTags.getCounter(word);

                Set<String> allowedFollowingTags = allowedFollowingTags(tagCounter.keySet(), localTrigramContext.getPreviousPreviousTag(), localTrigramContext.getPreviousTag());
                Counter<String> logScoreCounter = new Counter<String>();

                //loop thru all tags in the given word - for known words
                for (String tag : tagCounter.keySet()) {
                    double logScore;// = Math.log(tagCounter.getCount(tag));
                    if (!restrictTrigrams || allowedFollowingTags.isEmpty() || allowedFollowingTags.contains(tag))
                    {
                        //get q number for trigram without lambdas
                        String trigram = makeTrigramString(localTrigramContext.getPreviousPreviousTag(), localTrigramContext.getPreviousTag(), tag);
                        String bigram = makeBigramString(localTrigramContext.getPreviousTag(), tag);
                        double cTrigram = trigramTagStrings.getCount(trigram);
                        double cBigram = bigramTagStrings.getCount(bigram);
                        double cTrigramDenominator = bigramTagStrings.getCount(makeBigramString(localTrigramContext.getPreviousPreviousTag(), localTrigramContext.getPreviousTag()));
                        double cBigramDenominator = unigramTagStrings.getCount(localTrigramContext.getPreviousTag());
                        double qNumber = 0.0;
                        if(cTrigramDenominator > 0.0)
                            qNumber += lambda1 * cTrigram/cTrigramDenominator;
                        if(cBigramDenominator > 0.0)
                            qNumber += (lambda2 * cBigram/cBigramDenominator );
                        if(unigramTagStrings.totalCount()>0)
                            qNumber += (lambda3 * unigramTagStrings.getCount(tag)/ unigramTagStrings.totalCount());

                        //get e number for trigram without smoothing because the word is categorized into unkown
                        double eNumber = tagsToWords.getCount(tag, word)/ unigramTagStrings.getCount(tag);

                        //multiply q and e and take a log of it
                        logScore = Math.log(qNumber * eNumber);
                        logScoreCounter.setCount(tag, logScore);
                    }
                }

            return logScoreCounter;
        }

        private Set<String> allowedFollowingTags(Set<String> tags, String previousPreviousTag, String previousTag) {
            Set<String> allowedTags = new HashSet<String>();
            for (String tag : tags) {
                String trigramString = makeTrigramString(previousPreviousTag, previousTag, tag);
                if (trigramTagsCnt.contains((trigramString))) {
                    allowedTags.add(tag);
                }
            }
            return allowedTags;
        }

        private String makeTrigramString(String previousPreviousTag, String previousTag, String currentTag) {
            return previousPreviousTag + " " + previousTag + " " + currentTag;
        }
        private String makeBigramString(String previousTag, String currentTag) {
            return previousTag + " " + currentTag;
        }
        public void train(List<LabeledLocalTrigramContext> localTrigramContexts)
        {
            // collect word-tag counts
            for (LabeledLocalTrigramContext labeledLocalTrigramContext : localTrigramContexts)
            {
                String word = labeledLocalTrigramContext.getCurrentWord();
                String tag = labeledLocalTrigramContext.getCurrentTag();
                seenWords.incrementCount(word, 1.0);
                if (seenWords.getCount(word)<5)
                {
                    unkWordsToTags.incrementCount(word, tag, 1.0);
                }
                else //upgrade the word from unknown to the known list if it hasn't been
                {
                    //if first time, copy all the previous data from unkWordsToTags set
                    if(!wordsToTags.containsKey(word))
                    {
                        Counter<String> tagList = unkWordsToTags.getCounter(word);
                        for (String tagForPrevUnk:tagList.keySet())
                        {
                            wordsToTags.incrementCount(word, tagForPrevUnk, tagList.getCount(tagForPrevUnk));
                            tagsToWords.incrementCount(tagForPrevUnk, word, tagList.getCount(tagForPrevUnk));
                            //unkWordsToTags.getCounter(word).removeKey(tagForPrevUnk); //remove the tag-word relationship from UNK
                        }
                    }
                    wordsToTags.incrementCount(word, tag, 1.0);
                    tagsToWords.incrementCount(tag, word, 1.0);
                }

                String trigramStr = makeTrigramString(labeledLocalTrigramContext.getPreviousPreviousTag(), labeledLocalTrigramContext.getPreviousTag(), labeledLocalTrigramContext.getCurrentTag());
                String bigramStr = makeBigramString(labeledLocalTrigramContext.getPreviousTag(), labeledLocalTrigramContext.getCurrentTag());
                trigramTagsCnt.add(trigramStr);  //TODO: REPLACE THE CALL TO THIS WITH SOME QUERY USING trigramTagStrings
                bigramTagsCnt.add(bigramStr);

                //keep track of these counts for q number calculation
                trigramTagStrings.incrementCount(trigramStr, 1.0);
                bigramTagStrings.incrementCount(bigramStr, 1.0);
                unigramTagStrings.incrementCount(labeledLocalTrigramContext.getCurrentTag(), 1.0);
            }
            //wordsToTags = Counters.conditionalNormalize(wordsToTags);   //normalize after validate
            //unknownWordTags = Counters.normalize(unknownWordTags);
        }


        //this function adjust unknown words by turning them into pseudoWord
        // and finding the smoothing parameters
        public void validate(List<LabeledLocalTrigramContext> localTrigramContexts)
        {
            //
            // unseen words solver
            // go thru unknownWordTags
            // if count is more than or equal to 5, remove
            // else observe the word and change it to the unique word and give it a tag
            //
            for(String unkWord: seenWords.keySet())
            {
                //if(!unkWordsToTags.getCounter(unkWord).isEmpty())     //the word is less freq word
                if(seenWords.getCount(unkWord)<5)
                {
                    Counter<String> tagList = unkWordsToTags.getCounter(unkWord);
                    String pseudoWord = getPseudoString(unkWord);
                    for (String tag:tagList.keySet())
                    {
                        wordsToTags.incrementCount(pseudoWord, tag, tagList.getCount(tag));
                        tagsToWords.incrementCount(tag, pseudoWord, tagList.getCount(tag));
                        //unkWordsToTags.getCounter(unkWord).removeKey(tag); //remove the tag-word relationship from UNK
                    }
                }

            }

            wordsToTags = Counters.conditionalNormalize(wordsToTags);

            //
            // finding lambdas
            //TODO: FIND LAMBDAS
            //
            // collect word-tag counts


        }

        public BetterTagScorer(boolean restrictTrigrams) {
            this.restrictTrigrams = restrictTrigrams;
        }
    }

  private static List<TaggedSentence> readTaggedSentences(String path, int low, int high) {
    Collection<Tree<String>> trees = PennTreebankReader.readTrees(path, low, high);
    List<TaggedSentence> taggedSentences = new ArrayList<TaggedSentence>();
    Trees.TreeTransformer<String> treeTransformer = new Trees.EmptyNodeStripper();
    for (Tree<String> tree : trees) {
      tree = treeTransformer.transformTree(tree);
      List<String> words = new BoundedList<String>(new ArrayList<String>(tree.getYield()), START_WORD, STOP_WORD);
      List<String> tags = new BoundedList<String>(new ArrayList<String>(tree.getPreTerminalYield()), START_TAG, STOP_TAG);
      taggedSentences.add(new TaggedSentence(words, tags));
    }
    return taggedSentences;
  }

  private static void evaluateTagger(POSTagger posTagger, List<TaggedSentence> taggedSentences, Set<String> trainingVocabulary, boolean verbose) {
    double numTags = 0.0;
    double numTagsCorrect = 0.0;
    double numUnknownWords = 0.0;
    double numUnknownWordsCorrect = 0.0;
    int numDecodingInversions = 0;
    for (TaggedSentence taggedSentence : taggedSentences) {
      List<String> words = taggedSentence.getWords();
      List<String> goldTags = taggedSentence.getTags();
      List<String> guessedTags = posTagger.tag(words);
      for (int position = 0; position < words.size() - 1; position++) {
        String word = words.get(position);
        String goldTag = goldTags.get(position);
        String guessedTag = guessedTags.get(position);
        if (guessedTag.equals(goldTag))
          numTagsCorrect += 1.0;
        numTags += 1.0;
        if (!trainingVocabulary.contains(word)) {
          if (guessedTag.equals(goldTag))
            numUnknownWordsCorrect += 1.0;
          numUnknownWords += 1.0;
        }
      }
      double scoreOfGoldTagging = posTagger.scoreTagging(taggedSentence);
      double scoreOfGuessedTagging = posTagger.scoreTagging(new TaggedSentence(words, guessedTags));
      if (scoreOfGoldTagging > scoreOfGuessedTagging) {
        numDecodingInversions++;
        if (verbose) System.out.println("WARNING: Decoder suboptimality detected.  Gold tagging has higher score than guessed tagging.");
      }
      if (verbose) System.out.println(alignedTaggings(words, goldTags, guessedTags, true) + "\n");
    }
    System.out.println("Tag Accuracy: " + (numTagsCorrect / numTags) + " (Unknown Accuracy: " + (numUnknownWordsCorrect / numUnknownWords) + ")  Decoder Suboptimalities Detected: " + numDecodingInversions);
  }

  // pretty-print a pair of taggings for a sentence, possibly suppressing the tags which correctly match
  private static String alignedTaggings(List<String> words, List<String> goldTags, List<String> guessedTags, boolean suppressCorrectTags) {
    StringBuilder goldSB = new StringBuilder("Gold Tags: ");
    StringBuilder guessedSB = new StringBuilder("Guessed Tags: ");
    StringBuilder wordSB = new StringBuilder("Words: ");
    for (int position = 0; position < words.size(); position++) {
      equalizeLengths(wordSB, goldSB, guessedSB);
      String word = words.get(position);
      String gold = goldTags.get(position);
      String guessed = guessedTags.get(position);
      wordSB.append(word);
      if (position < words.size() - 1)
        wordSB.append(' ');
      boolean correct = (gold.equals(guessed));
      if (correct && suppressCorrectTags)
        continue;
      guessedSB.append(guessed);
      goldSB.append(gold);
    }
    return goldSB + "\n" + guessedSB + "\n" + wordSB;
  }

  private static void equalizeLengths(StringBuilder sb1, StringBuilder sb2, StringBuilder sb3) {
    int maxLength = sb1.length();
    maxLength = Math.max(maxLength, sb2.length());
    maxLength = Math.max(maxLength, sb3.length());
    ensureLength(sb1, maxLength);
    ensureLength(sb2, maxLength);
    ensureLength(sb3, maxLength);
  }

  private static void ensureLength(StringBuilder sb, int length) {
    while (sb.length() < length) {
      sb.append(' ');
    }
  }

  private static Set<String> extractVocabulary(List<TaggedSentence> taggedSentences) {
    Set<String> vocabulary = new HashSet<String>();
    for (TaggedSentence taggedSentence : taggedSentences) {
      List<String> words = taggedSentence.getWords();
      vocabulary.addAll(words);
    }
    return vocabulary;
  }

  public static void main(String[] args) {
    // Parse command line flags and arguments
    Map<String, String> argMap = CommandLineUtils.simpleCommandLineParser(args);

    // Set up default parameters and settings
    String basePath = ".";
    boolean verbose = false;
    boolean useValidation = true;

    // Update defaults using command line specifications

    // The path to the assignment data
    if (argMap.containsKey("-path")) {
      basePath = argMap.get("-path");
    }
    System.out.println("Using base path: " + basePath);

    // Whether to use the validation or test set
    if (argMap.containsKey("-test")) {
      String testString = argMap.get("-test");
      if (testString.equalsIgnoreCase("test"))
        useValidation = false;
    }
    System.out.println("Testing on: " + (useValidation ? "validation" : "test"));

    // Whether or not to print the individual errors.
    if (argMap.containsKey("-verbose")) {
      verbose = true;
    }

    // Read in data
    System.out.print("Loading training sentences...");
    List<TaggedSentence> trainTaggedSentences = readTaggedSentences(basePath, 200, 2199);
    Set<String> trainingVocabulary = extractVocabulary(trainTaggedSentences);
    System.out.println("done.");
    System.out.print("Loading validation sentences...");
    List<TaggedSentence> validationTaggedSentences = readTaggedSentences(basePath, 2200, 2299);
    System.out.println("done.");
    System.out.print("Loading test sentences...");
    List<TaggedSentence> testTaggedSentences = readTaggedSentences(basePath, 2300, 2399);
    System.out.println("done.");

    // Construct tagger components
    // TODO : improve on the MostFrequentTagScorer
    LocalTrigramScorer localTrigramScorer = new BetterTagScorer(false);
    // TODO : improve on the GreedyDecoder
    TrellisDecoder<State> trellisDecoder = new Viterbi<State>();//GreedyDecoder<State>();

    // Train tagger
    POSTagger posTagger = new POSTagger(localTrigramScorer, trellisDecoder);
    posTagger.train(trainTaggedSentences);
    posTagger.validate(validationTaggedSentences);

    // Evaluation set, use either test of validation (for dev)
    final List<TaggedSentence> evalTaggedSentences;
    if (useValidation) {
    	evalTaggedSentences = validationTaggedSentences;
    } else {
    	evalTaggedSentences = testTaggedSentences;
    }
    
    // Test tagger
    evaluateTagger(posTagger, evalTaggedSentences, trainingVocabulary, verbose);
  }
}
